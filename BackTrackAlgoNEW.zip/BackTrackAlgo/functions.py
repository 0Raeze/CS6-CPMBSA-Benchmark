import numpy as np

class BenchmarkFunctions:

    # SET-I: UNIMODAL FUNCTIONS (Exploitation)
    @staticmethod
    def sphere(x):
        """F1: The classic smooth bowl. Pure exploitation test."""
        return np.sum(x**2)

    @staticmethod
    def rosenbrock(x):
        """F2: The 'Banana Valley'. Hard to find the exact flat bottom."""
        return np.sum(100.0 * (x[1:] - x[:-1]**2)**2 + (x[:-1] - 1.0)**2)

    @staticmethod
    def zakharov(x):
        """F3 (New): Zakharov Function — curved, unimodal with interaction terms."""
        D = len(x)
        term1 = np.sum(x**2)
        term2 = np.sum(0.5 * np.arange(1, D + 1) * x)
        return term1 + term2**2 + term2**4

    # SET-II: MULTIMODAL FUNCTIONS (Exploration)
    @staticmethod
    def rastrigin(x):
        """F24: The 'Egg Carton' with many fake minimums."""
        D = len(x)
        return 10 * D + np.sum(x**2 - 10 * np.cos(2 * np.pi * x))

    @staticmethod
    def ackley(x):
        """F26: Flat planes with a deep, sudden hole in the center."""
        D = len(x)
        sum_sq = np.sum(x**2)
        sum_cos = np.sum(np.cos(2 * np.pi * x))
        term1 = -20 * np.exp(-0.2 * np.sqrt(sum_sq / D))
        term2 = -np.exp(sum_cos / D)
        return term1 + term2 + 20 + np.e

    @staticmethod
    def schwefel(x):
        """F27 (New): Schwefel — highly deceptive, multimodal with many local minima."""
        D = len(x)
        return 418.9829 * D - np.sum(x * np.sin(np.sqrt(np.abs(x))))

    # SET-III: FIXED-DIMENSION MULTIMODAL (Stability/Balance)
    @staticmethod
    def six_hump_camel(x):
        """F52: Highly complex 2D landscape with 6 local minimums."""
        x1, x2 = x[0], x[1]
        term1 = (4 - 2.1 * x1**2 + (x1**4) / 3) * x1**2
        term2 = x1 * x2
        term3 = (-4 + 4 * x2**2) * x2**2
        return term1 + term2 + term3

    @staticmethod
    def hartmann3(x):
        """F53 (New): Hartmann 3D — complex fixed-dimension multimodal function."""
        if len(x) != 3:
            raise ValueError("Hartmann 3D function requires 3 dimensions.")
        alpha = np.array([1.0, 1.2, 3.0, 3.2])
        A = np.array([
            [3.0, 10.0, 30.0],
            [0.1, 10.0, 35.0],
            [3.0, 10.0, 30.0],
            [0.1, 10.0, 35.0],
        ])
        P = 1e-4 * np.array([
            [3689, 1170, 2673],
            [4699, 4387, 7470],
            [1091, 8732, 5547],
            [381, 5743, 8828],
        ])
        outer = np.zeros(4)
        for i in range(4):
            inner = np.sum(A[i] * (x - P[i])**2)
            outer[i] = alpha[i] * np.exp(-inner)
        return -np.sum(outer)


# SUITE CONFIGURATION FOR THE MENU (Used in main.py)
FUNCTION_SUITE = {
    # 3 Unimodal Functions
    "F1_Sphere": {
        "func": BenchmarkFunctions.sphere,
        "bounds": [-100, 100],
        "dim": 40,
        "type": "Set-I: Unimodal (Exploitation)"
    },
    "F2_Rosenbrock": {
        "func": BenchmarkFunctions.rosenbrock,
        "bounds": [-30, 30],
        "dim": 40,
        "type": "Set-I: Unimodal (Exploitation)"
    },
    "F3_Zakharov": {
        "func": BenchmarkFunctions.zakharov,
        "bounds": [-10, 10],
        "dim": 40,
        "type": "Set-I: Unimodal (Exploitation)"
    },

    # 3 Multimodal Functions
    "F24_Rastrigin": {
        "func": BenchmarkFunctions.rastrigin,
        "bounds": [-5.12, 5.12],
        "dim": 40,
        "type": "Set-II: Multimodal (Exploration)"
    },
    "F26_Ackley": {
        "func": BenchmarkFunctions.ackley,
        "bounds": [-32, 32],
        "dim": 40,
        "type": "Set-II: Multimodal (Exploration)"
    },
    "F27_Schwefel": {
        "func": BenchmarkFunctions.schwefel,
        "bounds": [-500, 500],
        "dim": 40,
        "type": "Set-II: Multimodal (Exploration)"
    },

    # 2 Fixed-Dimension Functions
    "F52_SixHumpCamel": {
        "func": BenchmarkFunctions.six_hump_camel,
        "bounds": [-5, 5],
        "dim": 2,
        "type": "Set-III: Fixed-Dimension (Stability)"
    },
    "F53_Hartmann3": {
        "func": BenchmarkFunctions.hartmann3,
        "bounds": [0, 1],
        "dim": 3,
        "type": "Set-III: Fixed-Dimension (Stability)"
    }
}