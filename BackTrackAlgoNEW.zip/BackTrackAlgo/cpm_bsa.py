import numpy as np

class CPMBSA:
    def __init__(self, func, bounds, dim, pop_size=30, max_evals=9000, p_init=1.5, p_final=0.5):
        self.func = func
        # Extract low and high from the bounds list provided by FUNCTION_SUITE
        self.low = bounds[0]
        self.high = bounds[1]
        self.dim = dim
        self.pop_size = pop_size
        self.max_evals = max_evals
        self.max_iters = max_evals // pop_size
        self.p_init = p_init
        self.p_final = p_final

    def power_mutation(self, x, p):
        """Standard Power Mutation (PM) as defined in constrained optimization research."""
        u = np.random.rand(*x.shape)
        # s is the distribution factor based on the power parameter p
        s = np.where(u < 0.5, 
                     (2 * u)**(1/p), 
                     1 - (2 * (1 - u))**(1/p))
        
        # Scale mutation by the total search range
        return x + s * (self.high - self.low)

    def optimize(self):
        # --- INITIALIZATION ---
        pop = np.random.uniform(self.low, self.high, (self.pop_size, self.dim))
        # BSA Memory: Historical population
        old_pop = np.random.uniform(self.low, self.high, (self.pop_size, self.dim))
        
        # Initial fitness evaluation
        fit = np.array([self.func(ind) for ind in pop])

        # Track global best
        best_idx = np.argmin(fit)
        best_fit = fit[best_idx]
        best_pos = pop[best_idx].copy()

        for t in range(self.max_iters):
            # --- SELECTION I: Historical Population Update ---
            # BSA specific: Memory update with stochastic trigger
            if np.random.rand() < np.random.rand():
                old_pop = pop.copy()
            
            # Shuffle historical population to generate search directions
            perm_idx = np.random.permutation(self.pop_size)
            history = old_pop[perm_idx]

            # --- MAP GENERATION: BSA Dual-Strategy Crossover ---
            map_matrix = np.ones((self.pop_size, self.dim))
            if np.random.rand() < np.random.rand():
                for i in range(self.pop_size):
                    u = np.random.permutation(self.dim)[:int(np.random.rand() * self.dim) + 1]
                    map_matrix[i, u] = 0 # 0 indicates 'use mutant'
            else:
                for i in range(self.pop_size):
                    map_matrix[i, np.random.randint(self.dim)] = 0

            # --- MUTATION: BSA Basis + Power Mutation ---
            # F is the search scale factor (Research standard: 3 * normal distribution)
            F = 3 * np.random.standard_normal()
            
            # Base BSA direction
            mutant = pop + F * (history - pop)
            
            # CPM addition: Apply Power Mutation to refine the mutant
            # p decays to shift from global exploration to local exploitation
            p = self.p_init - (self.p_init - self.p_final) * (t / self.max_iters)
            mutant = self.power_mutation(mutant, p)

            # --- CROSSOVER ---
            trial = np.where(map_matrix == 0, mutant, pop)

            # --- BOUNDARY CONTROL (Random Re-initialization) ---
            # Essential for Rastrigin/Schwefel to maintain diversity at the edges
            out_mask = (trial < self.low) | (trial > self.high)
            if np.any(out_mask):
                trial[out_mask] = np.random.uniform(self.low, self.high, trial[out_mask].shape)

            # --- SELECTION II: Greedy Selection ---
            # Evaluate trial solutions
            trial_fit = np.array([self.func(ind) for ind in trial])
            
            improved = trial_fit < fit
            pop[improved] = trial[improved]
            fit[improved] = trial_fit[improved]
            
            # Update Global Best
            min_fit_idx = np.argmin(fit)
            if fit[min_fit_idx] < best_fit:
                best_fit = fit[min_fit_idx]
                best_pos = pop[min_fit_idx].copy()

        return best_fit, best_pos