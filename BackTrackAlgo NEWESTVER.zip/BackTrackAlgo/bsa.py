import numpy as np

class StandardBSA:
    def __init__(self, func, bounds, dim, pop_size=30, max_evals=9000):
        self.func = func
        self.low, self.high = bounds
        self.dim = dim
        self.pop_size = pop_size
        self.max_evals = max_evals
        self.max_iters = max_evals // pop_size
        self.cross_prob = 0.8
        self.F_range = (0.2, 2.0)

    def optimize(self):
        # --- Initialization ---
        pop = np.random.uniform(self.low, self.high, (self.pop_size, self.dim))
        fit = np.array([self.func(ind) for ind in pop])

        best_idx = np.argmin(fit)
        best_fit = fit[best_idx]
        best_pos = pop[best_idx].copy()

        # Track convergence
        convergence_history = [best_fit]

        for _ in range(self.max_iters):
            # Historical population
            old_pop = np.copy(pop)
            np.random.shuffle(old_pop)

            # Scaling factor
            F = np.random.uniform(self.F_range[0], self.F_range[1])

            # Mutation
            mutant = pop + F * (old_pop - pop)
            mutant = np.clip(mutant, self.low, self.high)

            # Crossover
            cross_mask = np.random.rand(self.pop_size, self.dim) < self.cross_prob
            trial = np.where(cross_mask, mutant, pop)

            # Selection
            trial_fit = np.array([self.func(ind) for ind in trial])
            improved = trial_fit < fit
            pop[improved] = trial[improved]
            fit[improved] = trial_fit[improved]

            # Update best
            cur_best_idx = np.argmin(fit)
            if fit[cur_best_idx] < best_fit:
                best_fit = float(fit[cur_best_idx])
                best_pos = pop[cur_best_idx].copy()

            # Record convergence
            convergence_history.append(best_fit)

        return best_fit, best_pos, convergence_history