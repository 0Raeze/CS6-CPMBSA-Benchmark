import numpy as np

class CPMBSA:
    def __init__(self, func, bounds, dim, pop_size=30, max_evals=9000, p_init=1.5, p_final=0.5):
        self.func = func
        self.low, self.high = bounds
        self.dim = dim
        self.pop_size = pop_size
        self.max_evals = max_evals
        self.max_iters = max_evals // pop_size
        self.p_init = p_init
        self.p_final = p_final

    def power_mutation(self, x, p):
        """Power Mutation (PM) as per CPMBSA research."""
        u = np.random.rand(*x.shape)
        s = np.where(u < 0.5,
                     (2 * u) ** (1 / p),
                     1 - (2 * (1 - u)) ** (1 / p))
        return x + s * (self.high - self.low)

    def optimize(self):
        # --- Initialization ---
        pop = np.random.uniform(self.low, self.high, (self.pop_size, self.dim))
        old_pop = np.random.uniform(self.low, self.high, (self.pop_size, self.dim))  # BSA historical memory
        fit = np.array([self.func(ind) for ind in pop])

        best_idx = np.argmin(fit)
        best_fit = fit[best_idx]
        best_pos = pop[best_idx].copy()

        # Track convergence uniformly
        convergence_history = [best_fit]

        for t in range(self.max_iters):
            # --- Historical Population Update (BSA) ---
            if np.random.rand() < np.random.rand():
                old_pop = pop.copy()

            # Shuffle historical population for search direction
            perm_idx = np.random.permutation(self.pop_size)
            history = old_pop[perm_idx]

            # --- Map Generation (Dual-Strategy Crossover) ---
            map_matrix = np.ones((self.pop_size, self.dim))
            if np.random.rand() < np.random.rand():
                for i in range(self.pop_size):
                    u = np.random.permutation(self.dim)[:int(np.random.rand() * self.dim) + 1]
                    map_matrix[i, u] = 0
            else:
                for i in range(self.pop_size):
                    map_matrix[i, np.random.randint(self.dim)] = 0

            # --- Mutation (BSA + CPM) ---
            F = 3 * np.random.standard_normal()  # scaling factor
            mutant = pop + F * (history - pop)
            # decaying p for global -> local transition
            p = self.p_init - (self.p_init - self.p_final) * (t / self.max_iters)
            mutant = self.power_mutation(mutant, p)

            # --- Crossover ---
            trial = np.where(map_matrix == 0, mutant, pop)

            # --- Boundary Control ---
            out_mask = (trial < self.low) | (trial > self.high)
            if np.any(out_mask):
                trial[out_mask] = np.random.uniform(self.low, self.high, trial[out_mask].shape)

            # --- Selection ---
            trial_fit = np.array([self.func(ind) for ind in trial])
            improved = trial_fit < fit
            pop[improved] = trial[improved]
            fit[improved] = trial_fit[improved]

            # --- Update Global Best ---
            min_fit_idx = np.argmin(fit)
            if fit[min_fit_idx] < best_fit:
                best_fit = fit[min_fit_idx]
                best_pos = pop[min_fit_idx].copy()

            # Record convergence
            convergence_history.append(best_fit)

        return best_fit, best_pos, convergence_history